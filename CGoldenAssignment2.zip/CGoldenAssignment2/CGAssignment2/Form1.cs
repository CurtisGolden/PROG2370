﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CGAssignment2
{
    /* Curtis Golden 7044241
     * PROG2370 Assignment2
     * Created: October 7th 2017
     */
     
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int count = 0;

        bool xCheck1;
        bool xCheck2;
        bool xCheck3;
        bool xCheck4;
        bool xCheck5;
        bool xCheck6;
        bool xCheck7;
        bool xCheck8;
        bool xCheck9;

        bool oCheck1;
        bool oCheck2;
        bool oCheck3;
        bool oCheck4;
        bool oCheck5;
        bool oCheck6;
        bool oCheck7;
        bool oCheck8;
        bool oCheck9;

        bool tieCheck1;
        bool tieCheck2;
        bool tieCheck3;
        bool tieCheck4;
        bool tieCheck5;
        bool tieCheck6;
        bool tieCheck7;
        bool tieCheck8;
        bool tieCheck9;

        //checks for 3 in a row and resets the game when a winner is found, or when a tie game occurs
        public void checkForWin()
        {
            //checks for x winning
            if (xCheck1 == true && xCheck2 == true && xCheck3 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck4 == true && xCheck5 == true && xCheck6 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck7 == true && xCheck8 == true && xCheck9 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck1 == true && xCheck4 == true && xCheck7 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck2 == true && xCheck5 == true && xCheck8 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck3 == true && xCheck6 == true && xCheck9 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck1 == true && xCheck5 == true && xCheck9 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }
            else if (xCheck3 == true && xCheck5 == true && xCheck7 == true)
            {
                MessageBox.Show("X wins!");
                resetGame();
            }


            //checks for o winning

            else if (oCheck1 == true && oCheck2 == true && oCheck3 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck4 == true && oCheck5 == true && oCheck6 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck7 == true && oCheck8 == true && oCheck9 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck1 == true && oCheck4 == true && oCheck7 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck2 == true && oCheck5 == true && oCheck8 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck3 == true && oCheck6 == true && oCheck9 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck1 == true && oCheck5 == true && oCheck9 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
            else if (oCheck3 == true && oCheck5 == true && oCheck7 == true)
            {
                MessageBox.Show("O wins!");
                resetGame();
            }
           

            // checks for a tie game
            else if (tieCheck1 == true && tieCheck2 == true && tieCheck3 == true && tieCheck4 == true && tieCheck5 == true && tieCheck6 == true && tieCheck7 == true && tieCheck8 == true && tieCheck9 == true) {
                MessageBox.Show("Tie Game!");
                resetGame();
            }

        }

        //Onclick method for picture boxes displays X or O based on count and checks for a win or tie
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox1.Image = CGAssignment2.Properties.Resources.X;
                pictureBox1.Enabled = false;


                xCheck1 = true;
                tieCheck1 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox1.Image = CGAssignment2.Properties.Resources.O;
                pictureBox1.Enabled = false;


                oCheck1 = true;
                tieCheck1 = true;
                count--;
                checkForWin();
            }


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox2.Image = CGAssignment2.Properties.Resources.X;
                pictureBox2.Enabled = false;


                xCheck2 = true;
                tieCheck2 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox2.Image = CGAssignment2.Properties.Resources.O;
                pictureBox2.Enabled = false;


                oCheck2 = true;
                tieCheck2 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox3.Image = CGAssignment2.Properties.Resources.X;
                pictureBox3.Enabled = false;


                xCheck3 = true;
                tieCheck3 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox3.Image = CGAssignment2.Properties.Resources.O;
                pictureBox3.Enabled = false;


                oCheck3 = true;
                tieCheck3 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox4.Image = CGAssignment2.Properties.Resources.X;
                pictureBox4.Enabled = false;


                xCheck4 = true;
                tieCheck4 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox4.Image = CGAssignment2.Properties.Resources.O;
                pictureBox4.Enabled = false;


                oCheck4 = true;
                tieCheck4 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox5.Image = CGAssignment2.Properties.Resources.X;
                pictureBox5.Enabled = false;


                xCheck5 = true;
                tieCheck5 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox5.Image = CGAssignment2.Properties.Resources.O;
                pictureBox5.Enabled = false;


                oCheck5 = true;
                tieCheck5 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox6.Image = CGAssignment2.Properties.Resources.X;
                pictureBox6.Enabled = false;


                xCheck6 = true;
                tieCheck6 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox6.Image = CGAssignment2.Properties.Resources.O;
                pictureBox6.Enabled = false;


                oCheck6 = true;
                tieCheck6 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox7.Image = CGAssignment2.Properties.Resources.X;
                pictureBox7.Enabled = false;


                xCheck7 = true;
                tieCheck7 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox7.Image = CGAssignment2.Properties.Resources.O;
                pictureBox7.Enabled = false;


                oCheck7 = true;
                tieCheck7 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox8.Image = CGAssignment2.Properties.Resources.X;
                pictureBox8.Enabled = false;


                xCheck8 = true;
                tieCheck8 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox8.Image = CGAssignment2.Properties.Resources.O;
                pictureBox8.Enabled = false;


                oCheck8 = true;
                tieCheck8 = true;
                count--;
                checkForWin();
            }

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {
                pictureBox9.Image = CGAssignment2.Properties.Resources.X;
                pictureBox9.Enabled = false;


                xCheck9 = true;
                tieCheck9 = true;
                count++;
                checkForWin();
            }
            else if (count == 1)
            {
                pictureBox9.Image = CGAssignment2.Properties.Resources.O;
                pictureBox9.Enabled = false;


                oCheck9 = true;
                tieCheck9 = true;
                count--;
                checkForWin();
            }

        }


        //resets the game to start again
        private void resetGame()
        {
            count = 0;

            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox4.Image = null;
            pictureBox5.Image = null;
            pictureBox6.Image = null;
            pictureBox7.Image = null;
            pictureBox8.Image = null;
            pictureBox9.Image = null;

            pictureBox1.Enabled = true;
            pictureBox2.Enabled = true;
            pictureBox3.Enabled = true;
            pictureBox4.Enabled = true;
            pictureBox5.Enabled = true;
            pictureBox6.Enabled = true;
            pictureBox7.Enabled = true;
            pictureBox8.Enabled = true;
            pictureBox9.Enabled = true;

            xCheck1 = false;
            xCheck2 = false;
            xCheck3 = false;
            xCheck4 = false;
            xCheck5 = false;
            xCheck6 = false;
            xCheck7 = false;
            xCheck8 = false;
            xCheck9 = false;

            oCheck1 = false;
            oCheck2 = false;
            oCheck3 = false;
            oCheck4 = false;
            oCheck5 = false;
            oCheck6 = false;
            oCheck7 = false;
            oCheck8 = false;
            oCheck9 = false;

            tieCheck1 = false;
            tieCheck2 = false;
            tieCheck3 = false;
            tieCheck4 = false;
            tieCheck5 = false;
            tieCheck6 = false;
            tieCheck7 = false;
            tieCheck8 = false;
            tieCheck9 = false;
        }
    }
}
